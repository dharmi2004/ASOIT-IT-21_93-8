var age=20;
if(age>18) {
    document.write("Person can Vote");
}
else{
    document.write("<b>Person can't Vote</b>");
}